import os
import json
import torch
import requests
from bs4 import BeautifulSoup
from django.conf import settings
from torchvision import models, transforms
from django.shortcuts import render
from django.contrib import messages
from .forms import ImageUploadForm
from torchvision.models import DenseNet121_Weights
from PIL import Image

# Load the ImageNet class labels
json_path = os.path.join(settings.BASE_DIR, 'static', 'imagenet_class_index.json')
with open(json_path, 'r') as f:
    imagenet_classes = {int(key): value[1] for key, value in json.load(f).items()}

# Load the pre-trained model
model = models.densenet121(weights=DenseNet121_Weights.IMAGENET1K_V1)
model.eval()

# Define the image transformation
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

def classify_image(request):
    if request.method == 'POST':
        form = ImageUploadForm(request.POST, request.FILES)
        if form.is_valid():
            # Check if an image is uploaded
            if 'image' not in request.FILES:
                messages.error(request, "Please upload an image before submitting.")
                return render(request, 'classifier/upload.html', {'form': form})

            # Ensure the media directory exists
            if not os.path.exists(settings.MEDIA_ROOT):
                os.makedirs(settings.MEDIA_ROOT)

            # Save the uploaded image
            image = form.cleaned_data['image']
            img_path = os.path.join(settings.MEDIA_ROOT, image.name)
            with open(img_path, 'wb+') as destination:
                for chunk in image.chunks():
                    destination.write(chunk)

            # Load and preprocess the image
            img = Image.open(img_path).convert('RGB')
            img = transform(img).unsqueeze(0)

            # Perform inference
            with torch.no_grad():
                outputs = model(img)
                _, predicted = outputs.max(1)
                prediction = imagenet_classes[predicted.item()]

            # Fetch details from DuckDuckGo
            query = prediction
            url = f'https://duckduckgo.com/html/?q={query}'
            response = requests.get(url)
            soup = BeautifulSoup(response.text, 'html.parser')

            # Extract search results
            search_results = []
            for result in soup.find_all('a', class_='result__a', limit=5):  # Limit to 5 results
                title = result.get_text()
                link = result['href']
                search_results.append({'title': title, 'link': link})

            # Pass prediction and search results to the template
            return render(request, 'classifier/result.html', {
                'prediction': prediction,
                'search_results': search_results
            })
    else:
        form = ImageUploadForm()

    return render(request, 'classifier/upload.html', {'form': form})

def about(request):
    return render(request, 'classifier/about.html')
